#! /bin/bash

# 打印常用命令行样例

echo "--举个例子,参考一下--"

if [ "$1" = "logs" ]; then
   	 echo "kubectl logs -f -n kubernetes-dashboard -l k8s-app=kubernetes-dashboard"
fi

if [ "$1" = "delete" ] || [ "$1" = "create" ]; then
	echo "kubectl $1 -n kubernetes-dashboard -l k8s-app=kubernetes-dashboard"
fi

if [ "$1" = "cm" ] || [ "$1" = "configmap" ]; then
	echo "kubectl get cm  -n kubernetes-dashboard -l k8s-app=kubernetes-dashboard"
fi

if [ "$1" = "edit" ]; then
	echo "kubectl edit cm kube-proxy -n kube-system"
fi


if [ "$1" = "pods" ] || [ "$1" = "A" ]; then
	echo "kubectl get pods -A  -l k8s-app=kubernetes-dashboard"
fi

if [ "$1" = "dns" ]; then
	echo "kubectl get pod -l k8s-app=kube-dns -A"
fi
