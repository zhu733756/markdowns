.. meta:: 
   :description: Learn how to use NGINX Ingress Controller for Kubernetes with NGINX App Protect.

Ingress Controller with App Protect
===================================

.. toctree::
   :maxdepth: 2

   installation
   configuration
   troubleshooting
