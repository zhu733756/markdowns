# VirtualServer and VirtualServerRoute Resources

This doc is now available at https://docs.nginx.com/nginx-ingress-controller/configuration/virtualserver-and-virtualserverroute-resources/