# Installing the Ingress Controller

This doc is now available at https://docs.nginx.com/nginx-ingress-controller/installation/installation-with-manifests/