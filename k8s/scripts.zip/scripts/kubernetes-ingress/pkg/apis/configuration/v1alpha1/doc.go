// +k8s:deepcopy-gen=package
// +groupName=k8s.nginx.org

// Package v1alpha1 is the v1alpha1 version of the API.
package v1alpha1
